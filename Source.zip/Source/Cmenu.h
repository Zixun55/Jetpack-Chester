// namespace game_framework {
// 	/////////////////////////////////////////////////////////////////////////////
// 	// 這個class提供繞圈圈的球
// 	// 看懂就可以改寫成自己的程式了
// 	/////////////////////////////////////////////////////////////////////////////

// 	class Cmenu
// 	{
// 	public:
// 		Cmenu();
// 		bool IsAlive();											// 是否活著
// 		void LoadBitmap();										// 載入圖形
// 		void OnShow();											// 將圖形貼到畫面
// 		void SetXY(int nx, int ny);								// 設定圓心的座標
// 		void SetIsAlive(bool alive);							// 設定是否活著
// 		void SetDelay(int d);	
//         void OnLButtonUp(UINT nFlags, CPoint point);							
// 	protected:		
// 		CMovingBitmap background;
// 		CMovingBitmap character_image;
// 	private:

// 	};
// }
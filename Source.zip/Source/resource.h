//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ ���ͪ� Include �ɮסC
// �� game.rc �ϥ�
//
#define IDD_ABOUTBOX                    100
#define IDP_SOCKETS_INIT_FAILED         104
#define IDR_MAINFRAME                   128
#define IDR_GAMETYPE                    129
#define IDB_BALL                        130
#define IDB_RACKET                      131
#define IDB_ERASER1                     131
#define IDB_BITMAP1                     132
#define IDB_BACKGROUND                  132
#define IDB_CORNER                      133
#define IDB_BALL1                       134
#define IDB_BALL2                       135
#define IDB_BALL3                       136
#define IDB_BALL4                       137
#define IDB_0                           138
#define IDB_1                           139
#define IDB_2                           140
#define IDB_3                           141
#define IDB_4                           142
#define IDB_5                           143
#define IDB_6                           144
#define IDB_7                           145
#define IDB_8                           146
#define IDB_9                           147
#define IDB_MINUS                       148
#define IDB_CENTER                      149
#define IDB_ERASER2                     150
#define IDB_ERASER3                     151
#define IDB_CONTINUE                    152
#define IDC_GAMECURSOR                  153
#define IDB_HELP                        155
#define IDB_BITMAP2                     156
#define IDB_LOADING                     156
#define IDB_BITMAP3                     157
#define IDC_README                      1001
#define ID_FILE_PAUSE                   32771
#define ID_TOGGLE_FULLSCREEN            32772
#define ID_BUTTON_FULLSCREEN            32773
#define ID_BUTTON_PAUSE                 32774
#define ID_BUTTON_UNITTEST              32775

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        158
#define _APS_NEXT_COMMAND_VALUE         32776
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
